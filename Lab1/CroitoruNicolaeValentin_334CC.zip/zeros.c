#include <stdio.h>

int zeros (int n) {
    // cazul cand n = 0;
    if (n == 0) {
        return 1;
    }
    // cazul de baza
    else if (n < 10) {
        return 0;
    }
    // compararea ultimei cifre cu 0;
    else if (n % 10 == 0) {
        return zeros(n / 10) + 1;
    }
    else {
        return zeros(n / 10);
    }
}

int main() {
    printf("%d\n", zeros(0));
    printf("%d\n", zeros(20000));
    printf("%d\n", zeros(123));
    return 0;
}
