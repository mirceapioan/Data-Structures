#include <stdio.h>
#include <math.h>

void odd(int v[], int n, int i);
void even(int v[], int n, int i);

void odd(int v[], int n, int i) {
    if (i == n) {
        return;
    }
    v[i] = pow(v[i], 3);
    even(v, n, i + 1);
}

void even(int v[], int n, int i) {
    if (i == n) {
        return;
    }
    v[i] = pow(v[i], 2);
    odd(v, n, i + 1);
}

int main() {
    int v[] = {1, -1, 0, 2, 3, 2, 4};
    int len = sizeof(v) / sizeof(int);

    even(v, len, 0);
    for (int i = 0; i < len; i++) {
        printf("%d ", v[i]);
    }
    printf("\n");
}
