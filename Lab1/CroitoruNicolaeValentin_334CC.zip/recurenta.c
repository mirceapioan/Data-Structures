#include <stdio.h>

int recurenta(int n) {
    if (n == 0) {
        return 0;
    }
    else if (n == 1) {
        return 1;
    }
    else {  // n > 1
        return 3 * recurenta(n - 1) - 2 * recurenta(n - 2) + 3;
    }
}

int main() {
    printf("%d\n", recurenta(7));
}
