#include<stdio.h>
#include<string.h>

int distanta(char *s1, char *s2) {
    if (strlen(s1) != strlen(s2)) {
        return -1;
    }
    
    if(strlen(s1) == 0) {
        return 0;
    }

    if (s1[0] == s2[0]) {
        return distanta(s1 + 1, s2 + 1); 
    } else if (s1[0] != s2[0]) {
        return 1 + distanta(s1 + 1, s2 + 1);
    }
}

int main() {

    printf("%d\n", distanta("MARTHA", "MARHTA"));
    printf("%d\n", distanta("AAA", "AAAA"));

    return 0;
}