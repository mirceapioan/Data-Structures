#include <stdio.h>

int difference(int v[], int n, int i) {
    if (i == n) {
        return 0;
    }
    if (v[i] % 2 == 0) {
        return v[i] + difference(v, n, i + 1);
    }
    else if (v[i] % 2 == 1) {
        return difference(v, n, i + 1) - v[i];
    }
}

int main() {
    int v1[] = {1, 2, 2, 3, 4, 1, 3, 2};
    int len1 = sizeof(v1) / sizeof(int);
    printf("%d\n", difference(v1, len1, 0));

    int v2[] = {1, 2, 4, 5};
    int len2 = sizeof(v2) / sizeof(int);
    printf("%d\n", difference(v2, len2, 0));

    return 0;
}